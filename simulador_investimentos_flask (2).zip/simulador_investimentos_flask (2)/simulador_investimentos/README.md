# Simulador de investimentos — primeira etapa

Aplicação Flask + Jinja2 com login e página de boas-vindas. Ainda não há cadastro público, banco de dados nem simulação de investimentos.

## Executar

**No Windows:** instale Python 3.10 ou superior com a opção **Add python.exe to PATH**, extraia o ZIP e dê dois cliques em `iniciar.bat`. Na primeira execução, o arquivo instala as dependências e abre o login no navegador. Deixe a janela aberta enquanto usar o sistema. As próximas execuções são mais rápidas.

**Em outros sistemas**, use os comandos abaixo:

Use Python 3.10 ou superior:

```bash
python -m venv .venv
source .venv/bin/activate          # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
python -m flask --app 'app:create_app' run
```

No PowerShell, defina a chave com:

```powershell
$env:SECRET_KEY = python -c "import secrets; print(secrets.token_hex(32))"
python -m flask --app 'app:create_app' run
```

Abra http://127.0.0.1:5000/login e entre com o usuário `demo`. A senha inicial acompanha a entrega deste projeto; o arquivo `app/model/users.json` guarda apenas seu hash. A chave deve permanecer estável entre reinicializações se você quiser preservar as sessões existentes; não publique a chave nem use o servidor de desenvolvimento na internet.

Para cadastrar manualmente outro usuário, gere um hash com `python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('SUA_SENHA'))"` e acrescente ao JSON um objeto com `id` (único), `username` (único), `name` e `password_hash`. Não salve senhas em texto puro.

## Organização MVC

- `app/model/users.py` lê os usuários de `app/model/users.json` e valida hashes.
- `app/controllers/auth.py` é o blueprint de login e saída; `home.py` atende a página inicial.
- `app/view/` contém as telas Jinja2.
- `app/middleware/auth.py` verifica a autenticação antes das rotas privadas.
- `app/__init__.py` cria e configura a aplicação. Para usar um banco no futuro, substitua o acesso aos usuários no model, preservando a interface usada pelos controllers e middleware.

## Controle de acesso e limites

O navegador envia um cookie de sessão **assinado** pelo Flask com a chave `SECRET_KEY`; dentro dele fica somente o identificador do usuário, nunca a senha. Antes de servir `/bem-vindo`, o middleware confere se esse identificador ainda corresponde a um usuário do arquivo. Sem usuário válido, redireciona para `/login`. O login confere um hash de senha com Werkzeug, limpa a sessão antiga e cria uma sessão com prazo máximo de 30 minutos; sair exige POST com token CSRF e limpa a sessão atual. Formulários usam token CSRF, e o cookie usa `HttpOnly` e `SameSite=Lax`.

Para disponibilizar o sistema com HTTPS, configure `COOKIE_SECURE=true` e uma `SECRET_KEY` longa e privada, além de servidor WSGI adequado. O cookie assinado não permite alteração sem a chave, mas uma cópia de cookie obtida por terceiros ainda pode ser reutilizada até expirar; para revogação imediata por dispositivo ou escala maior, passe a usar sessões no servidor ao integrar o banco. Também adicione limite de tentativas de login na infraestrutura antes de abrir acesso público.

## Testes

```bash
python -m pip install pytest
python -m pytest -q
```
