import os
from flask import Flask

def create_app():
    app = Flask(__name__)
    
    # Configuração necessária para permitir o uso de sessões (session)
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'chave_secreta_desenvolvimento_123')

    # ... registro de blueprints e middleware ...
    from .controllers.auth import auth_bp
    app.register_blueprint(auth_bp)

    from .middleware.auth import register_auth_guard
    register_auth_guard(app)

    return app