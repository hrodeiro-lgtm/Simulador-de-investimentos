from flask import session, request, redirect, url_for, g
from ..model.users import find_by_id

def register_auth_guard(app):
    @app.before_request
    def load_logged_in_user():
        """Carrega o usuário logado na variável global g antes de cada requisição."""
        user_id = session.get("user_id")
        if user_id is None:
            g.user = None
        else:
            g.user = find_by_id(user_id)

    @app.before_request
    def check_auth():
        """Redireciona para o login caso o usuário tente acessar rotas protegidas sem autenticação."""
        # Rotas públicas e arquivos estáticos que não exigem autenticação
        public_endpoints = ["auth.login", "static"]

        if request.endpoint and request.endpoint not in public_endpoints:
            if g.user is None:
                return redirect(url_for("auth.login"))