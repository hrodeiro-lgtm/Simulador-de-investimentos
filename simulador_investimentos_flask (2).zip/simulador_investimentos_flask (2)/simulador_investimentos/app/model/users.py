import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

# Caminho do ficheiro da base de dados salvo na pasta do model
DB_PATH = os.path.join(os.path.dirname(__file__), 'simulador.db')

def init_db():
    """Cria a base de dados e a tabela de utilizadores se não existirem."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Insere utilizadores de teste se a tabela estiver vazia
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        utilizadores = [
            ('admin', generate_password_hash('admin123')),
            ('joao', generate_password_hash('senha123'))
        ]
        cursor.executemany("INSERT INTO users (username, password_hash) VALUES (?, ?)", utilizadores)
        conn.commit()
        
    conn.close()

def find_by_username(username):
    """Procura um utilizador na base de dados pelo nome de utilizador."""
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, username, password_hash FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()

    if row:
        return {
            "id": row[0],
            "username": row[1],
            "password_hash": row[2]
        }
    return None

def find_by_id(user_id):
    """Procura um utilizador na base de dados pelo ID (usado pelo middleware)."""
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, username, password_hash FROM users WHERE id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()

    if row:
        return {
            "id": row[0],
            "username": row[1],
            "password_hash": row[2]
        }
    return None

def verify_credentials(username, password):
    """Valida as credenciais do utilizador."""
    user = find_by_username(username)
    if user and check_password_hash(user["password_hash"], password):
        return True
    return False