from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash
from ..model.users import find_by_username

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = find_by_username(username)

        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Usuário ou senha inválidos.", "danger")
            return render_template("login.html")

        # Limpa e grava a sessão
        session.clear()
        session["user_id"] = user["id"]
        session["username"] = user["username"]

        # Redireciona diretamente para a página principal
        return redirect("/")

    return render_template("login.html")

@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))