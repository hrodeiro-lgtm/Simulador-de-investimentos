from flask import Blueprint, g, redirect, render_template, url_for

from .auth import csrf_token

home_bp = Blueprint("home", __name__)


@home_bp.get("/")
def index():
    return redirect(url_for("home.welcome"))


@home_bp.get("/bem-vindo")
def welcome():
    return render_template("welcome.html", name=g.user.name, csrf_token=csrf_token())
