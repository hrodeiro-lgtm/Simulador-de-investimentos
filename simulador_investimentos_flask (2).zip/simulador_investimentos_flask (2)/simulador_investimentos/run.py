"""Atalho local para abrir o login no navegador e iniciar o Flask."""

import threading
import webbrowser

from app import create_app


if __name__ == "__main__":
    app = create_app()
    threading.Timer(2, lambda: webbrowser.open("http://127.0.0.1:5000/login")).start()
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)
