"""Clique em Run Python File ou execute python run.py para abrir o NEXO."""

import os
import secrets
import subprocess
import sys
import threading
import venv
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV_FILE = ROOT / ".env"
PORT = 5055


def bootstrap_python():
    """Prepara dependências no ambiente do projeto, inclusive no primeiro clique."""
    python = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    requirements = ROOT / "requirements.txt"
    marker = ROOT / ".venv" / ".requirements-ok"
    if not python.exists():
        print("Preparando o Python do projeto pela primeira vez...")
        venv.EnvBuilder(with_pip=True).create(ROOT / ".venv")
    if not marker.exists() or requirements.stat().st_mtime > marker.stat().st_mtime:
        subprocess.check_call([str(python), "-m", "pip", "install", "-r", str(requirements)])
        marker.touch()
    if Path(sys.executable).resolve() != python.resolve():
        os.execv(str(python), [str(python), str(ROOT / "run.py")])


if __name__ == "__main__":
    bootstrap_python()

from dotenv import load_dotenv, set_key
from app import create_app


def main():
    load_dotenv(ENV_FILE)
    if not os.environ.get("SECRET_KEY"):
        key = secrets.token_hex(32)
        ENV_FILE.touch(exist_ok=True)
        set_key(str(ENV_FILE), "SECRET_KEY", key)
        os.environ["SECRET_KEY"] = key

    app = create_app({"ENV_FILE": ENV_FILE})
    configured = app.config["DATABASE_BACKEND"] == "sqlite" or bool(
        app.config.get("SQLSERVER_SERVER") and app.config.get("SQLSERVER_DATABASE")
    )
    if configured:
        try:
            repo = app.extensions["user_repository"]
            repo.ensure_schema()
            configured = repo.has_users()
        except Exception:
            app.logger.warning("Banco indisponível; abrindo configuração no navegador")
            configured = False
    app.config["SETUP_REQUIRED"] = not configured
    path = "/login" if configured else "/configurar"
    url = f"http://127.0.0.1:{PORT}" + path
    print("Abra no navegador:", url)
    threading.Timer(2, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=PORT, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
