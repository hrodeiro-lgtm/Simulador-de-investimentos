#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 não encontrado. Instale Python 3.10 ou superior."
  exit 1
fi

if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi

if [ ! -f .venv/.requirements-ok ] || [ requirements.txt -nt .venv/.requirements-ok ]; then
  .venv/bin/python -m pip install -r requirements.txt
  touch .venv/.requirements-ok
fi

exec .venv/bin/python run.py
