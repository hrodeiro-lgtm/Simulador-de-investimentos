@echo off
setlocal
cd /d "%~dp0"
title NEXO - Simulador de investimentos

if exist ".venv\Scripts\python.exe" goto environment_ready

where py >nul 2>nul
if not errorlevel 1 (
    py -3 -m venv .venv
) else (
    where python >nul 2>nul
    if errorlevel 1 goto python_missing
    python -m venv .venv
)
if errorlevel 1 goto setup_failed

:environment_ready
if not exist ".venv\Scripts\python.exe" goto setup_failed
if not exist ".venv\instalado.ok" (
    echo Preparando o projeto pela primeira vez...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto setup_failed
    type nul > ".venv\instalado.ok"
)

echo.
echo Iniciando o sistema...
echo Para encerrar, feche esta janela ou pressione Ctrl+C.
".venv\Scripts\python.exe" run.py
if errorlevel 1 goto setup_failed
exit /b 0

:python_missing
echo Python 3 nao foi encontrado. Instale Python 3.10 ou superior e execute este arquivo novamente.
echo Durante a instalacao, marque "Add python.exe to PATH".
pause
exit /b 1

:setup_failed
echo.
echo Nao foi possivel iniciar. Confira a mensagem acima.
pause
exit /b 1
