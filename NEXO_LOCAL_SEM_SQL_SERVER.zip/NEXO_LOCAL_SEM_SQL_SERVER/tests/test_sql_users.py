from app.model.users import SqlServerUserRepository
from werkzeug.security import check_password_hash


class Cursor:
    def __init__(self, row):
        self.row = row
        self.query = None
        self.params = None

    def execute(self, query, *params):
        self.query, self.params = query, params
        return self

    def fetchone(self):
        return self.row


class Connection:
    def __init__(self, cursor):
        self.result = cursor

    def cursor(self):
        return self.result

    def close(self):
        pass

    def commit(self):
        self.committed = True


def test_lookup_uses_parameter_instead_of_interpolating_username():
    cursor = Cursor((7, "demo", "Usuário Demo", "hash"))
    repo = SqlServerUserRepository(lambda: Connection(cursor))
    user = repo.find_by_username("demo' OR 1=1 --")
    assert cursor.params == ("demo' OR 1=1 --",)
    assert "demo' OR 1=1 --" not in cursor.query
    assert user.id == 7


def test_lookup_returns_none_when_user_missing():
    repo = SqlServerUserRepository(lambda: Connection(Cursor(None)))
    assert repo.find_by_id(999) is None


def test_initial_user_is_inserted_with_password_hash():
    cursor = Cursor(None)
    connection = Connection(cursor)
    repo = SqlServerUserRepository(lambda: connection)
    repo.create_user("demo", "Usuário Demo", "senha-com-12-caracteres")
    assert cursor.params[:2] == ("demo", "Usuário Demo")
    assert cursor.params[2] != "senha-com-12-caracteres"
    assert check_password_hash(cursor.params[2], "senha-com-12-caracteres")
    assert connection.committed
