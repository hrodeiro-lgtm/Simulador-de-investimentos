import re

import pytest
from werkzeug.security import generate_password_hash

from app import create_app
from app.model.users import User


class MemoryUsers:
    def __init__(self):
        self.users = {1: User(1, "demo", "Usuário Demo", generate_password_hash("senha-de-teste"))}

    def find_by_id(self, user_id):
        return self.users.get(int(user_id))

    def find_by_username(self, username):
        return next((user for user in self.users.values() if user.username == username), None)


@pytest.fixture
def client():
    app = create_app({"TESTING": True, "SECRET_KEY": "test-secret-long-enough", "USER_REPOSITORY": MemoryUsers()})
    return app.test_client()


def token(client):
    html = client.get("/login").get_data(as_text=True)
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


def test_private_page_requires_authentication(client):
    response = client.get("/bem-vindo")
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/login")


def test_login_requires_csrf_and_valid_password(client):
    assert client.post("/login", data={"username": "demo", "password": "senha-de-teste"}).status_code == 400
    csrf = token(client)
    bad = client.post("/login", data={"username": "demo", "password": "errada", "csrf_token": csrf})
    assert bad.status_code == 401
    assert client.get("/bem-vindo").status_code == 302
    ok = client.post("/login", data={"username": "demo", "password": "senha-de-teste", "csrf_token": csrf})
    assert ok.status_code == 302
    assert ok.headers["Location"].endswith("/bem-vindo")
    assert "Usuário Demo" in client.get("/bem-vindo").get_data(as_text=True)


def test_logout_clears_session_and_requires_csrf(client):
    csrf = token(client)
    client.post("/login", data={"username": "demo", "password": "senha-de-teste", "csrf_token": csrf})
    assert client.get("/logout").status_code == 405
    assert client.post("/logout").status_code == 400
    welcome_html = client.get("/bem-vindo").get_data(as_text=True)
    logout_token = re.search(r'name="csrf_token" value="([^"]+)"', welcome_html).group(1)
    assert client.post("/logout", data={"csrf_token": logout_token}).status_code == 302
    assert client.get("/bem-vindo").status_code == 302


def test_removed_user_cannot_continue_using_session(client):
    csrf = token(client)
    client.post("/login", data={"username": "demo", "password": "senha-de-teste", "csrf_token": csrf})
    client.application.extensions["user_repository"].users.clear()
    assert client.get("/bem-vindo").status_code == 302


def test_secret_key_must_be_set(monkeypatch):
    monkeypatch.delenv("SECRET_KEY", raising=False)
    with pytest.raises(RuntimeError, match="SECRET_KEY"):
        create_app()
