import re

from app import create_app
from app.model.users import User
from werkzeug.security import check_password_hash


class SetupUsers:
    def __init__(self):
        self.user = None

    def ensure_schema(self):
        pass

    def has_users(self):
        return self.user is not None

    def create_user(self, username, name, password):
        from werkzeug.security import generate_password_hash
        self.user = User(1, username, name, generate_password_hash(password))

    def find_by_id(self, user_id):
        return self.user if self.user and int(user_id) == self.user.id else None

    def find_by_username(self, username):
        return self.user if self.user and username == self.user.username else None


def test_first_run_configures_database_and_allows_login(tmp_path):
    repo = SetupUsers()
    app = create_app({
        "TESTING": True, "SECRET_KEY": "secret-for-test", "SETUP_REQUIRED": True,
        "DATABASE_BACKEND": "sqlserver",
        "ENV_FILE": tmp_path / ".env", "USER_REPOSITORY_FACTORY": lambda config: repo,
    })
    client = app.test_client()
    assert client.get("/login").headers["Location"].endswith("/configurar")
    page = client.get("/configurar")
    assert page.status_code == 200
    csrf = re.search(r'name="csrf_token" value="([^"]+)"', page.get_data(as_text=True)).group(1)
    assert client.post("/configurar", data={"server": "localhost"}).status_code == 400
    response = client.post("/configurar", data={
        "csrf_token": csrf, "server": "localhost", "database": "simulador",
        "trusted": "yes", "username": "demo", "display_name": "Demo",
        "password": "senha-de-teste-longa", "confirm_password": "senha-de-teste-longa",
    })
    assert response.status_code == 302
    assert response.headers["Location"].endswith("/login")
    assert app.config["SETUP_REQUIRED"] is False
    assert repo.user and check_password_hash(repo.user.password_hash, "senha-de-teste-longa")
    assert "SQLSERVER_SERVER='localhost'" in (tmp_path / ".env").read_text()
    login_html = client.get("/login").get_data(as_text=True)
    login_token = re.search(r'name="csrf_token" value="([^"]+)"', login_html).group(1)
    assert client.post("/login", data={
        "csrf_token": login_token, "username": "demo", "password": "senha-de-teste-longa"
    }).status_code == 302


def test_local_database_first_run_needs_no_sql_server(tmp_path):
    path = tmp_path / "nexo.sqlite3"
    app = create_app({
        "TESTING": True, "SECRET_KEY": "secret-for-test", "SETUP_REQUIRED": True,
        "DATABASE_BACKEND": "sqlite", "SQLITE_DB": path,
    })
    client = app.test_client()
    page = client.get("/configurar").get_data(as_text=True)
    assert "Servidor" not in page
    csrf = re.search(r'name="csrf_token" value="([^"]+)"', page).group(1)
    response = client.post("/configurar", data={
        "csrf_token": csrf, "username": "lucas", "display_name": "Lucas",
        "password": "minha-senha-segura", "confirm_password": "minha-senha-segura",
    })
    assert response.status_code == 302
    assert path.exists()
    login_html = client.get("/login").get_data(as_text=True)
    login_token = re.search(r'name="csrf_token" value="([^"]+)"', login_html).group(1)
    response = client.post("/login", data={
        "csrf_token": login_token, "username": "lucas", "password": "minha-senha-segura",
    })
    assert response.status_code == 302
    assert "Lucas" in client.get("/bem-vindo").get_data(as_text=True)
