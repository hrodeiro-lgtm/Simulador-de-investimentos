# NEXO — login inicial com Flask

Aplicação mínima com tela de login e página de boas-vindas. O banco local é criado automaticamente pelo Python na pasta `data/`. Você não precisa instalar SQL Server para experimentar.

## Rodar com um clique

Tenha Python 3.10 ou superior instalado. Extraia o ZIP, abra `run.py` no VS Code e clique em **Run Python File** (▶). Também pode dar dois cliques em `iniciar.bat` no Windows, ou usar `bash iniciar.sh` no Linux.

Na primeira execução, o programa instala as dependências Python, abre o navegador e pede que você crie **seu usuário e sua senha**. Depois, abre a tela de login diretamente. Mantenha o processo Python em execução enquanto usa o sistema.

Esta versão abre em `http://127.0.0.1:5055`. A página inicial correta mostra “Crie seu usuário. O banco local será preparado automaticamente.” Se aparecerem campos de servidor SQL Server, feche o processo antigo e abra o `run.py` desta pasta extraída.

O cadastro fica em `data/nexo.sqlite3`, um banco SQLite local que não deve ser enviado para outra pessoa. A chave da sessão fica em `.env`. Ambos são ignorados pelo Git e não acompanham o ZIP.

## SQL Server depois

O código para SQL Server continua disponível, mas requer um servidor, um banco já criado e o ODBC Driver 18. Quando tiver esses recursos, instale `requirements-sqlserver.txt` e defina `DATABASE_BACKEND=sqlserver` no arquivo `.env`. O navegador solicitará os dados de conexão e permitirá criar o primeiro usuário nesse banco. O banco local e o SQL Server mantêm usuários separados.

## Organização

- `app/model/`: acesso aos bancos e validação de hash de senha.
- `app/controllers/`: configuração, login e página protegida.
- `app/middleware/`: confere a sessão antes das rotas privadas.
- `app/view/`: páginas Jinja2; `app/static/`: CSS.
- `run.py`: prepara e inicia a aplicação local.

As senhas são armazenadas apenas como hashes; a sessão guarda o ID do usuário e os formulários usam token CSRF. Antes de disponibilizar o sistema na internet, configure HTTPS, cookie seguro, limite de tentativas de login e servidor apropriado.

## Testes

Com as dependências e pytest instalados: `python -m pytest -q`.
