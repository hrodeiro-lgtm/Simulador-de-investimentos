from flask import Blueprint, g, redirect, render_template, request, url_for

from app.model.investments import Investment
from .auth import check_csrf, csrf_token

home_bp = Blueprint("home", __name__)


@home_bp.get("/")
def index():
    return redirect(url_for("home.welcome"))


@home_bp.route("/bem-vindo", methods=["GET", "POST"])
def welcome():
    # Garante a existência da tabela
    Investment.ensure_schema()

    if request.method == "POST":
        check_csrf()
        
        # Ação para eliminar
        delete_id = request.form.get("delete_id")
        if delete_id:
            inv = Investment(id=int(delete_id))
            inv.delete()
            return redirect(url_for("home.welcome"))

        # Ação para criar novo investimento
        name = request.form.get("name", "").strip()
        category = request.form.get("category", "").strip()
        try:
            amount = float(request.form.get("amount", 0))
            if name and category and amount > 0:
                Investment.create_investment(
                    user_id=g.user.id,
                    name=name,
                    category=category,
                    amount=amount
                )
        except ValueError:
            pass

        return redirect(url_for("home.welcome"))

    # Busca a lista de investimentos da base de dados no GET
    investments = Investment.find_by_user_id(g.user.id)
    total_amount = sum(inv.amount for inv in investments)

    return render_template(
        "welcome.html",
        name=g.user.name,
        investments=investments,
        total_amount=total_amount,
        csrf_token=csrf_token()
    )