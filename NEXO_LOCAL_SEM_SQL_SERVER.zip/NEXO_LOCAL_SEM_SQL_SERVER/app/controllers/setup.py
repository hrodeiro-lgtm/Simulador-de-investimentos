"""Formulário local usado apenas na primeira configuração."""

from pathlib import Path

from dotenv import set_key
from flask import Blueprint, abort, current_app, redirect, render_template, request, session, url_for

from .auth import check_csrf, csrf_token

setup_bp = Blueprint("setup", __name__)


@setup_bp.route("/configurar", methods=["GET", "POST"])
def configure():
    if request.remote_addr not in {"127.0.0.1", "::1"}:
        abort(403)
    backend = current_app.config["DATABASE_BACKEND"]
    if request.method == "GET":
        return render_template("setup.html", csrf_token=csrf_token(), backend=backend)

    check_csrf()
    server = request.form.get("server", "").strip()
    database = request.form.get("database", "").strip()
    trusted = request.form.get("trusted") == "yes"
    db_user = request.form.get("db_user", "").strip()
    db_password = request.form.get("db_password", "")
    username = request.form.get("username", "").strip()
    display_name = request.form.get("display_name", "").strip()
    password = request.form.get("password", "")
    if backend == "sqlite":
        if password != request.form.get("confirm_password", ""):
            return render_template("setup.html", csrf_token=csrf_token(), backend=backend, error="As senhas não coincidem."), 400
        repository = current_app.extensions["user_repository"]
        try:
            repository.ensure_schema()
            if not repository.has_users():
                repository.create_user(username, display_name, password)
        except ValueError as error:
            return render_template("setup.html", csrf_token=csrf_token(), backend=backend, error=str(error)), 400
        session.clear()
        current_app.config["SETUP_REQUIRED"] = False
        return redirect(url_for("auth.login"))
    if not server or not database or (not trusted and (not db_user or not db_password)):
        return render_template("setup.html", csrf_token=csrf_token(), backend=backend, error="Preencha os dados da conexão."), 400
    if password != request.form.get("confirm_password", ""):
        return render_template("setup.html", csrf_token=csrf_token(), backend=backend, error="As senhas do usuário não coincidem."), 400

    config = dict(current_app.config)
    settings = {
        "SQLSERVER_SERVER": server,
        "SQLSERVER_DATABASE": database,
        "SQLSERVER_TRUSTED_CONNECTION": "yes" if trusted else "no",
        "SQLSERVER_USER": "" if trusted else db_user,
        "SQLSERVER_PASSWORD": "" if trusted else db_password,
        "SQLSERVER_TRUST_CERTIFICATE": "yes" if request.form.get("trust_cert") == "yes" else "no",
    }
    config.update(settings)
    repository = current_app.config["USER_REPOSITORY_FACTORY"](config)
    try:
        repository.ensure_schema()
        if not repository.has_users():
            repository.create_user(username, display_name, password)
    except ValueError as error:
        return render_template("setup.html", csrf_token=csrf_token(), backend=backend, error=str(error)), 400
    except Exception:
        current_app.logger.exception("Falha na configuração do banco")
        return render_template("setup.html", csrf_token=csrf_token(), backend=backend, error="Não foi possível conectar. Confira servidor, banco, acesso e ODBC Driver 18."), 400

    env_file = Path(current_app.config["ENV_FILE"])
    env_file.touch(exist_ok=True)
    for key, value in settings.items():
        set_key(str(env_file), key, value)
    current_app.config.update(settings)
    current_app.extensions["user_repository"] = repository
    current_app.config["SETUP_REQUIRED"] = False
    session.clear()
    return redirect(url_for("auth.login"))
