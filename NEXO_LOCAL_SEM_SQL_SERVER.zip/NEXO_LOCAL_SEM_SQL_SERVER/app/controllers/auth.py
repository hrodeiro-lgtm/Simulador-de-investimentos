import secrets

from flask import Blueprint, abort, current_app, g, redirect, render_template, request, session, url_for

auth_bp = Blueprint("auth", __name__)


def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def check_csrf():
    submitted = request.form.get("csrf_token", "")
    expected = session.get("csrf_token", "")
    if not expected or not secrets.compare_digest(submitted, expected):
        abort(400)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        if g.user:
            return redirect(url_for("home.welcome"))
        return render_template("login.html", csrf_token=csrf_token())

    check_csrf()
    user = current_app.extensions["user_repository"].find_by_username(request.form.get("username", ""))
    if user is None or not user.verify_password(request.form.get("password", "")):
        return render_template("login.html", csrf_token=csrf_token(), error="Usuário ou senha inválidos."), 401

    session.clear()
    session["user_id"] = user.id
    session.permanent = True
    return redirect(url_for("home.welcome"))


@auth_bp.post("/logout")
def logout():
    check_csrf()
    session.clear()
    return redirect(url_for("auth.login"))
