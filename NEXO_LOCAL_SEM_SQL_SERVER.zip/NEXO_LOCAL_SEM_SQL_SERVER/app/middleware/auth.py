from flask import current_app, g, redirect, request, session, url_for


def register_auth_guard(app):
    @app.before_request
    def require_login():
        if app.config.get("SETUP_REQUIRED"):
            g.user = None
            if request.endpoint not in {"setup.configure", "static"}:
                return redirect(url_for("setup.configure"))
            return None

        if request.endpoint == "setup.configure":
            return redirect(url_for("auth.login"))
        user_id = session.get("user_id")
        g.user = current_app.extensions["user_repository"].find_by_id(user_id) if user_id else None
        if user_id and g.user is None:
            session.clear()

        public_endpoints = {"auth.login", "static"}
        if request.endpoint not in public_endpoints and g.user is None:
            return redirect(url_for("auth.login"))
