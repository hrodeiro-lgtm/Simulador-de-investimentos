"""Gerenciador de conexão com a base de dados SQLite utilizando Context Manager."""

from pathlib import Path
import sqlite3


class DatabaseConnection:
    """
    Classe gerenciadora de conexões com a base de dados SQLite.
    Implementa o protocolo Context Manager (__enter__ e __exit__)
    e configura sqlite3.Row para acesso às colunas pelo nome.
    """

    def __init__(self, db_path=None):
        if db_path is None:
            db_path = Path(__file__).resolve().parents[2] / "data" / "nexo.sqlite3"
        self.db_path = Path(db_path)
        self.connection = None

    def __enter__(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.db_path)
        # Configura sqlite3.Row para permitir acesso por nome de coluna (ex: row['username'])
        self.connection.row_factory = sqlite3.Row
        return self.connection.cursor()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.connection:
            if exc_type is not None:
                # Cancela a transação em caso de erro no bloco
                self.connection.rollback()
            else:
                # Confirma as alterações se não houver exceções
                self.connection.commit()
            self.connection.close()


def _quoted(value):
    return "{" + str(value).replace("}", "}}") + "}"


def connect(config):
    """Conexão ODBC para SQL Server mantida para compatibilidade."""
    import pyodbc

    server = config.get("SQLSERVER_SERVER")
    database = config.get("SQLSERVER_DATABASE")
    if not server or not database:
        raise RuntimeError("Configure SQLSERVER_SERVER e SQLSERVER_DATABASE no arquivo .env.")

    parts = [
        "DRIVER={ODBC Driver 18 for SQL Server}",
        "SERVER=" + _quoted(server),
        "DATABASE=" + _quoted(database),
        "Encrypt=yes",
        "TrustServerCertificate=" + ("yes" if config.get("SQLSERVER_TRUST_CERTIFICATE") == "yes" else "no"),
    ]
    if config.get("SQLSERVER_TRUSTED_CONNECTION") == "yes":
        parts.append("Trusted_Connection=yes")
    else:
        if not config.get("SQLSERVER_USER") or not config.get("SQLSERVER_PASSWORD"):
            raise RuntimeError("Defina SQLSERVER_USER e SQLSERVER_PASSWORD no arquivo .env.")
        parts.extend(["UID=" + _quoted(config["SQLSERVER_USER"]), "PWD=" + _quoted(config["SQLSERVER_PASSWORD"])])
    return pyodbc.connect(";".join(parts) + ";", timeout=5)