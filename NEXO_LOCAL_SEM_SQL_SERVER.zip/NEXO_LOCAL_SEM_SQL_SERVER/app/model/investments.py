"""Modelo de Investimento no padrão Active Record."""

from pathlib import Path
from .database import DatabaseConnection


class Investment:
    """
    Modelo de Investimento.
    Armazena os investimentos associados a cada utilizador.
    """

    DEFAULT_DB_PATH = Path(__file__).resolve().parents[2] / "data" / "nexo.sqlite3"

    def __init__(self, id=None, user_id=None, name="", category="", amount=0.0, db_path=None):
        self.id = id
        self.user_id = user_id
        self.name = name
        self.category = category
        self.amount = float(amount)
        self.db_path = db_path or self.DEFAULT_DB_PATH


    def save(self):
        """Guarda ou atualiza o investimento na base de dados."""
        with DatabaseConnection(self.db_path) as cursor:
            if self.id is None:
                cursor.execute(
                    "INSERT INTO investments (user_id, name, category, amount) VALUES (?, ?, ?, ?)",
                    (self.user_id, self.name, self.category, self.amount)
                )
                self.id = cursor.lastrowid
            else:
                cursor.execute(
                    "UPDATE investments SET user_id = ?, name = ?, category = ?, amount = ? WHERE id = ?",
                    (self.user_id, self.name, self.category, self.amount, self.id)
                )
        return self

    def delete(self):
        """Elimina o investimento da base de dados."""
        if self.id:
            with DatabaseConnection(self.db_path) as cursor:
                cursor.execute("DELETE FROM investments WHERE id = ?", (self.id,))
            self.id = None

 #busca por investimentos da tabela 
    @classmethod
    def _from_row(cls, row, db_path=None):
        """Mapeia uma linha do sqlite3.Row para a instância acedendo às colunas pelo nome."""
        if not row:
            return None
        return cls(
            id=row['id'],
            user_id=row['user_id'],
            name=row['name'],
            category=row['category'],
            amount=row['amount'],
            db_path=db_path
        )
#Garante a criação na tabela 
    @classmethod
    def ensure_schema(cls, db_path=None):
        """Garante a criação da tabela de investimentos."""
        path = db_path or cls.DEFAULT_DB_PATH
        with DatabaseConnection(path) as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS investments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    category TEXT NOT NULL,
                    amount REAL NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            """)
#Encontra os usuariios pelo ID 
    @classmethod
    def find_by_user_id(cls, user_id, db_path=None):
        """Retorna a lista de investimentos de um utilizador específico."""
        path = db_path or cls.DEFAULT_DB_PATH
        with DatabaseConnection(path) as cursor:
            cursor.execute(
                "SELECT id, user_id, name, category, amount FROM investments WHERE user_id = ?",
                (user_id,)
            )
            rows = cursor.fetchall()
            return [cls._from_row(row, db_path=path) for row in rows]

    #FInfalemnte cria o tipo de investimneto 
    @classmethod
    def create_investment(cls, user_id, name, category, amount, db_path=None):
        """Cria e guarda um novo investimento."""
        investment = cls(user_id=user_id, name=name, category=category, amount=amount, db_path=db_path)
        investment.save()
        return investment