"""Modelo de utilizador implementando o padrão Active Record."""

from pathlib import Path
from werkzeug.security import check_password_hash, generate_password_hash

from .database import DatabaseConnection


class User:
    """
    Modelo de Utilizador no padrão Active Record.
    Reúne atributos do objeto, comportamentos de instância (save, delete, verify_password)
    e métodos de classe para consultas à base de dados.
    """

    DEFAULT_DB_PATH = Path(__file__).resolve().parents[2] / "data" / "nexo.sqlite3"

    def __init__(self, id=None, username="", name="", password_hash="", db_path=None):
        self.id = id
        self.username = username
        self.name = name  # Mapeado para a coluna 'display_name' na base de dados
        self.password_hash = password_hash
        self.db_path = db_path or self.DEFAULT_DB_PATH

    # --- Comportamento do Objeto (Métodos de Instância) ---

    def verify_password(self, password: str) -> bool:
        """Verifica se a palavra-passe fornecida corresponde ao hash armazenado."""
        return check_password_hash(self.password_hash, password)

    def set_password(self, password: str):
        """Atualiza a palavra-passe do utilizador gerando um novo hash seguro."""
        if len(password) < 12:
            raise ValueError("A palavra-passe deve ter pelo menos 12 caracteres.")
        self.password_hash = generate_password_hash(password)

    def save(self):
        """Guarda a instância na base de dados (Insert se novo ou Update se já existir ID)."""
        with DatabaseConnection(self.db_path) as cursor:
            if self.id is None:
                cursor.execute(
                    "INSERT INTO users (username, display_name, password_hash) VALUES (?, ?, ?)",
                    (self.username, self.name, self.password_hash)
                )
                self.id = cursor.lastrowid
            else:
                cursor.execute(
                    "UPDATE users SET username = ?, display_name = ?, password_hash = ? WHERE id = ?",
                    (self.username, self.name, self.password_hash, self.id)
                )
        return self

    def delete(self):
        """Elimina a própria instância da base de dados."""
        if self.id:
            with DatabaseConnection(self.db_path) as cursor:
                cursor.execute("DELETE FROM users WHERE id = ?", (self.id,))
            self.id = None

    # --- Métodos de Classe (Buscas e Gestão da Tabela) ---

    @classmethod
    def _from_row(cls, row, db_path=None):
        """Converte um registo sqlite3.Row numa instância de User acedendo pelo nome da coluna."""
        if not row:
            return None
        return cls(
            id=row['id'],
            username=row['username'],
            name=row['display_name'],  # Acesso direto à coluna pelo nome
            password_hash=row['password_hash'],
            db_path=db_path
        )

    @classmethod
    def ensure_schema(cls, db_path=None):
        """Garante a criação da tabela de utilizadores se não existir."""
        path = db_path or cls.DEFAULT_DB_PATH
        with DatabaseConnection(path) as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    display_name TEXT NOT NULL,
                    password_hash TEXT NOT NULL
                )
            """)

    @classmethod
    def has_users(cls, db_path=None) -> bool:
        """Verifica se existe pelo menos um utilizador registado."""
        path = db_path or cls.DEFAULT_DB_PATH
        with DatabaseConnection(path) as cursor:
            cursor.execute("SELECT 1 FROM users LIMIT 1")
            return cursor.fetchone() is not None

    @classmethod
    def find_by_id(cls, user_id, db_path=None):
        """Procura um utilizador pelo ID."""
        try:
            numeric_id = int(user_id)
        except (TypeError, ValueError):
            return None

        path = db_path or cls.DEFAULT_DB_PATH
        with DatabaseConnection(path) as cursor:
            cursor.execute(
                "SELECT id, username, display_name, password_hash FROM users WHERE id = ?",
                (numeric_id,)
            )
            row = cursor.fetchone()
            return cls._from_row(row, db_path=path)

    @classmethod
    def find_by_username(cls, username, db_path=None):
        """Procura um utilizador pelo nome de utilizador (username)."""
        path = db_path or cls.DEFAULT_DB_PATH
        with DatabaseConnection(path) as cursor:
            cursor.execute(
                "SELECT id, username, display_name, password_hash FROM users WHERE username = ?",
                (username,)
            )
            row = cursor.fetchone()
            return cls._from_row(row, db_path=path)

    @classmethod
    def all(cls, db_path=None):
        """Retorna todos os utilizadores registados na base de dados."""
        path = db_path or cls.DEFAULT_DB_PATH
        with DatabaseConnection(path) as cursor:
            cursor.execute("SELECT id, username, display_name, password_hash FROM users")
            rows = cursor.fetchall()
            return [cls._from_row(row, db_path=path) for row in rows]

    @classmethod
    def create_user(cls, username, name, password, db_path=None):
        """Método de utilidade para criar e guardar um novo utilizador com validação."""
        if not username or not name or len(password) < 12:
            raise ValueError("Informe utilizador, nome e uma palavra-passe com pelo menos 12 caracteres.")

        pw_hash = generate_password_hash(password)
        user = cls(username=username, name=name, password_hash=pw_hash, db_path=db_path)
        user.save()
        return user

    def __repr__(self):
        return f"<User id={self.id} username='{self.username}' name='{self.name}'>"


# Classes legadas mantidas para retrocompatibilidade com repositórios legados
class SqliteUserRepository:
    def __init__(self, path):
        self.path = path

    def ensure_schema(self):
        User.ensure_schema(self.path)

    def has_users(self):
        return User.has_users(self.path)

    def find_by_id(self, user_id):
        return User.find_by_id(user_id, self.path)

    def find_by_username(self, username):
        return User.find_by_username(username, self.path)

    def create_user(self, username, name, password):
        return User.create_user(username, name, password, db_path=self.path)


class SqlServerUserRepository:
    def __init__(self, connector):
        self.connector = connector

    def _lookup(self, query, value):
        connection = self.connector()
        try:
            row = connection.cursor().execute(query, value).fetchone()
            return User(int(row[0]), row[1], row[2], row[3]) if row else None
        finally:
            connection.close()

    def find_by_id(self, user_id):
        try:
            numeric_id = int(user_id)
        except (TypeError, ValueError):
            return None
        return self._lookup(
            "SELECT id, username, display_name, password_hash FROM dbo.users WHERE id = ?", numeric_id
        )

    def find_by_username(self, username):
        return self._lookup(
            "SELECT id, username, display_name, password_hash FROM dbo.users WHERE username = ?", username
        )

    def ensure_schema(self):
        connection = self.connector()
        try:
            connection.cursor().execute("""
                IF OBJECT_ID(N'dbo.users', N'U') IS NULL
                CREATE TABLE dbo.users (
                    id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                    username NVARCHAR(100) NOT NULL UNIQUE,
                    display_name NVARCHAR(150) NOT NULL,
                    password_hash NVARCHAR(512) NOT NULL
                )
            """)
            connection.commit()
        finally:
            connection.close()

    def has_users(self):
        connection = self.connector()
        try:
            return connection.cursor().execute("SELECT TOP 1 id FROM dbo.users").fetchone() is not None
        finally:
            connection.close()

    def create_user(self, username, name, password):
        if not username or not name or len(password) < 12:
            raise ValueError("Informe usuário, nome e uma senha com pelo menos 12 caracteres.")
        connection = self.connector()
        try:
            connection.cursor().execute(
                "INSERT INTO dbo.users (username, display_name, password_hash) VALUES (?, ?, ?)",
                username, name, generate_password_hash(password),
            )
            connection.commit()
        finally:
            connection.close()