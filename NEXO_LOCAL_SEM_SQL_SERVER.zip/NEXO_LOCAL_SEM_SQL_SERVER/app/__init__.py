import os
from datetime import timedelta
from pathlib import Path

from flask import Flask

from .controllers.auth import auth_bp
from .controllers.home import home_bp
from .controllers.setup import setup_bp
from .middleware.auth import register_auth_guard
from .model.users import SqlServerUserRepository, SqliteUserRepository
from .model.database import connect


def create_app(test_config=None):
    app = Flask(__name__, template_folder="view", static_folder="static")
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY"),
        SETUP_REQUIRED=False,
        DATABASE_BACKEND=os.environ.get("DATABASE_BACKEND", "sqlite"),
        SQLITE_DB=Path(__file__).resolve().parents[1] / "data" / "nexo.sqlite3",
        SQLSERVER_SERVER=os.environ.get("SQLSERVER_SERVER"),
        SQLSERVER_DATABASE=os.environ.get("SQLSERVER_DATABASE"),
        SQLSERVER_TRUSTED_CONNECTION=os.environ.get("SQLSERVER_TRUSTED_CONNECTION", "yes"),
        SQLSERVER_USER=os.environ.get("SQLSERVER_USER"),
        SQLSERVER_PASSWORD=os.environ.get("SQLSERVER_PASSWORD"),
        SQLSERVER_TRUST_CERTIFICATE=os.environ.get("SQLSERVER_TRUST_CERTIFICATE", "no"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "false").lower() == "true",
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),
        SESSION_REFRESH_EACH_REQUEST=False,
    )
    if test_config:
        app.config.update(test_config)
    if not app.config["SECRET_KEY"]:
        raise RuntimeError("Defina SECRET_KEY no ambiente antes de iniciar a aplicação.")
    if "USER_REPOSITORY_FACTORY" not in app.config:
        if app.config["DATABASE_BACKEND"] == "sqlite":
            app.config["USER_REPOSITORY_FACTORY"] = lambda config: SqliteUserRepository(config["SQLITE_DB"])
        elif app.config["DATABASE_BACKEND"] == "sqlserver":
            app.config["USER_REPOSITORY_FACTORY"] = lambda config: SqlServerUserRepository(lambda: connect(config))
        else:
            raise ValueError("DATABASE_BACKEND deve ser sqlite ou sqlserver.")
    if "USER_REPOSITORY" in app.config:
        app.extensions["user_repository"] = app.config["USER_REPOSITORY"]
    else:
        app.extensions["user_repository"] = app.config["USER_REPOSITORY_FACTORY"](app.config)

    register_auth_guard(app)
    app.register_blueprint(auth_bp)
    app.register_blueprint(home_bp)
    app.register_blueprint(setup_bp)

    @app.after_request
    def set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Cache-Control"] = "no-store"
        return response

    return app
