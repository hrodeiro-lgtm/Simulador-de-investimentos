from flask import Blueprint, render_template, redirect, url_for, session
from app.middleware.auth_middleware import login_required

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    return redirect(url_for('auth.login'))

@main_bp.route('/welcome')
@login_required
def welcome():
    return render_template('welcome.html', username=session.get('username'))
