from werkzeug.security import generate_password_hash, check_password_hash

USERS_DB = {
    "admin": generate_password_hash("admin123"),
    "joao": generate_password_hash("senha123")
}

def verify_credentials(username, password):
    user_hash = USERS_DB.get(username)
    if user_hash and check_password_hash(user_hash, password):
        return True
    return False
