import os
from flask import Flask

def create_app():
    base_dir = os.path.abspath(os.path.dirname(__file__))
    view_dir = os.path.join(base_dir, '..', 'view')

    app = Flask(__name__, template_folder=view_dir)
    app.secret_key = 'chave_super_secreta_para_desenvolvimento'

    from app.controllers.auth_controller import auth_bp
    from app.controllers.main_controller import main_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)

    return app
